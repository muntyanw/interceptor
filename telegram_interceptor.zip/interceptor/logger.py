import logging

# Настройка базового логгера
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
